# @nexora/diagnostic-catalog

Version 0.1.0. NEXORA owns this standalone Node package and its public terminology
snapshot. It has no PMC server, Case, patient, database, model or network dependency.
PMC's connector can pass an already-authorized name/unit and render the result;
its RU/EN aliases and human-review workflow remain in PMC.

```ts
import { getDiagnosticCatalog } from "@nexora/diagnostic-catalog";
const result = getDiagnosticCatalog().resolve({ name: "LOINC: 1988-5", unit: "mg/L" });
```

This returns reference metadata, never a patient finding or an accepted clinical
mapping. Name lookup reports candidate count/truncation. Declared codes can be
found, unknown or conflicting. Matching never verifies a clinical fact, converts
units, infers missing specimen/method or modifies a source. The limited unit list
is not a complete UCUM grammar validator. Only public terms are cached globally.

Build at repository root with `npm run build:catalog`, then
`npm pack ./packages/diagnostic-catalog`. The tarball includes compiled JS/types,
the versioned data and licenses. A consumer may pin that exact artifact locally
with its npm integrity and source-commit receipt; this requires neither a running
NEXORA API nor private Git credentials on the consumer's production server.
The consumer artifact is generated distribution, not a second editable source.
Do not publish a public API or activate model adapters as a side effect.

See [data provenance and limits](data/README.md) and [licenses](data/licenses/ATTRIBUTIONS.md).
